#if !(UNITY_QNX) // Disable under unsupported platforms.
/*******************************************************************************
The content of this file includes portions of the proprietary AUDIOKINETIC Wwise
Technology released in source code form as part of the game integration package.
The content of this file may not be used without valid licenses to the
AUDIOKINETIC Wwise Technology.
Note that the use of the game engine is subject to the Unity(R) Terms of
Service at https://unity3d.com/legal/terms-of-service
 
License Usage
 
Licensees holding valid licenses to the AUDIOKINETIC Wwise Technology may use
this file in accordance with the end user license agreement provided with the
software or, alternatively, in accordance with the terms contained
in a written agreement between you and Audiokinetic Inc.
Copyright (c) 2026 Audiokinetic Inc.
*******************************************************************************/

public class AkSourceSettingsArray : AkBaseArray<AkSourceSettings>
{
	public AkSourceSettingsArray(int count) : base(count)
	{
	}

	protected override int StructureSize
	{
		get { return AkUnitySoundEnginePINVOKE.CSharp_AkSourceSettings_GetSizeOf(); }
	}

	protected override void DefaultConstructAtIntPtr(System.IntPtr address)
	{
		AkUnitySoundEnginePINVOKE.CSharp_AkSourceSettings_Clear(address);
	}

	protected override AkSourceSettings CreateNewReferenceFromIntPtr(System.IntPtr address)
	{
		return new AkSourceSettings(address, false);
	}

	protected override void CloneIntoReferenceFromIntPtr(System.IntPtr address, AkSourceSettings other)
	{
		AkUnitySoundEnginePINVOKE.CSharp_AkSourceSettings_Clone(address, AkSourceSettings.getCPtr(other));
	}
}
#endif // #if !(UNITY_QNX) // Disable under unsupported platforms.