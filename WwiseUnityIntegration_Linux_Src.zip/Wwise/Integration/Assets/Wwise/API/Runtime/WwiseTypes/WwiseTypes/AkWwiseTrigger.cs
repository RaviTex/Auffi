/*******************************************************************************
The content of this file includes portions of the proprietary AUDIOKINETIC Wwise
Technology released in source code form as part of the game integration package.
The content of this file may not be used without valid licenses to the
AUDIOKINETIC Wwise Technology.
Note that the use of the game engine is subject to the Unity(R) Terms of
Service at https://unity3d.com/legal/terms-of-service
 
License Usage
 
Licensees holding valid licenses to the AUDIOKINETIC Wwise Technology may use
this file in accordance with the end user license agreement provided with the
software or, alternatively, in accordance with the terms contained
in a written agreement between you and Audiokinetic Inc.
Copyright (c) 2026 Audiokinetic Inc.
*******************************************************************************/

#if !(UNITY_QNX) // Disable under unsupported platforms.

namespace AK.Wwise
{
	[System.Serializable]
	///@brief This type can be used to post triggers to the sound engine.
	public class Trigger : BaseType
	{
		public WwiseTriggerReference WwiseObjectReference;

		public override WwiseObjectReference ObjectReference
		{
			get { return WwiseObjectReference; }
			set { WwiseObjectReference = value as WwiseTriggerReference; }
		}

		public override WwiseObjectType WwiseObjectType { get { return WwiseObjectType.Trigger; } }

		public void Post(UnityEngine.GameObject gameObject)
		{
			if (IsValid())
			{
				var result = AkUnitySoundEngine.PostTrigger(Id, gameObject);
				Verify(result);
			}
		}
	}
}
#endif // #if !(UNITY_QNX) // Disable under unsupported platforms.